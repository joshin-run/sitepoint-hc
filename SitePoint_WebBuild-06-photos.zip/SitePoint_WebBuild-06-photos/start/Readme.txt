Issues:

1. no real margin under phone image
2. images do not change size when altering size of browser window pane
3. photos have white space

/* may need a .col-medium */

photos says .col-medium --- but does not have one in layout.css